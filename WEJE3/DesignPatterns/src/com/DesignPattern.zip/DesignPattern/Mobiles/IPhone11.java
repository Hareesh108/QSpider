package com.DesignPattern.Mobiles;

import com.DesignPattern.Mobile.Mobile;

public class IPhone11 implements Mobile {
	
	@Override
	public void start() {
		System.out.println("IPhone11 Started");
	}
}
