package com.DesignPattern.Mobiles;

import com.DesignPattern.Mobile.Mobile;

public class Poco implements Mobile {
	@Override
	public void start() {
		System.out.println("Poco Started");
	}
}
