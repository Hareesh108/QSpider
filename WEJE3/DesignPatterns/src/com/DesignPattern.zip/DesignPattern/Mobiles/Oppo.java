package com.DesignPattern.Mobiles;

import com.DesignPattern.Mobile.Mobile;

public class Oppo implements Mobile {
	@Override
	public void start() {
		System.out.println("Oppo Started");
	}
}
