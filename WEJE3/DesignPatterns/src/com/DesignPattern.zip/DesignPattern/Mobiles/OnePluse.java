package com.DesignPattern.Mobiles;

import com.DesignPattern.Mobile.Mobile;

public class OnePluse implements Mobile {
	@Override
	public void start() {
		System.out.println("OnePluse Started");
	}
}
