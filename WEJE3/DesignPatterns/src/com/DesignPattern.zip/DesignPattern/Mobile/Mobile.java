package com.DesignPattern.Mobile;

public interface Mobile {
	void start();
}
